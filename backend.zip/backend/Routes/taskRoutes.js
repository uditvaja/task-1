// routes/taskRoutes.js

const express = require('express');
const router = express.Router();
const { auth, admin } = require('../middleware/authMiddleware');
const Task = require('../models/task');

// Get all tasks (Admin sees all tasks, User sees their own)
router.get('/', auth, async (req, res) => {
  try {
    const tasks = req.user.role === 'admin' ? await Task.find() : await Task.find({ user: req.user.userId });
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create a task
router.post('/', auth, async (req, res) => {
  const { description, category } = req.body;
  try {
    const task = new Task({ user: req.user.userId, description, category });
    await task.save();
    res.status(201).json(task);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update a task
router.put('/:id', auth, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });

    // Check if the user is the owner of the task or an admin
    if (req.user.role !== 'admin' && task.user.toString() !== req.user.userId.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const updatedTask = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedTask);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete a task
router.delete('/:id', auth, async (req, res) => {
  try {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ message: 'Task not found' });

    // Check if the user is the owner of the task or an admin
    if (req.user.role !== 'admin' && task.user.toString() !== req.user.userId.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    await Task.findByIdAndDelete(req.params.id);
    res.json({ message: 'Task deleted' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
